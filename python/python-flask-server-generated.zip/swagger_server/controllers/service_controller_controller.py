import connexion
import six

from swagger_server.models.generic_json import GenericJSON  # noqa: E501
from swagger_server import util


def get_service_health():  # noqa: E501
    """Returns service health 

    Returns service health # noqa: E501


    :rtype: GenericJSON
    """
    return 'do some magic!'


def get_service_information():  # noqa: E501
    """Returns service information 

    Returns service information # noqa: E501


    :rtype: GenericJSON
    """
    return 'do some magic!'
